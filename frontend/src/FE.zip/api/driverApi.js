import axiosClient from "./axiosClient";
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

// ====== MOCK DATA ======
let MOCK_TRIPS = [
  {
    id: 1,
    customerName: "Nguyễn Văn A",
    customerPhone: "0901 234 567",
    route: "Q1 → Sân bay Tân Sơn Nhất",
    pickupTime: "08:30 16/01/2026",
    status: "ASSIGNED",
    price: 250000,
    startPoint: [10.7769, 106.7009], // Q1
    endPoint: [10.8188, 106.6519], // TSN
  },
  {
    id: 2,
    customerName: "Trần Thị B",
    customerPhone: "0912 888 999",
    route: "Quận 7 → Quận 3",
    pickupTime: "09:15 16/01/2026",
    status: "CONFIRMED",
    price: 180000,
    startPoint: [10.7366, 106.7219],
    endPoint: [10.7825, 106.684],
  },
  {
    id: 3,
    customerName: "Lê Hoàng C",
    customerPhone: "0988 555 222",
    route: "Bình Thạnh → Landmark 81",
    pickupTime: "10:00 16/01/2026",
    status: "IN_PROGRESS",
    price: 120000,
    startPoint: [10.8032, 106.712],
    endPoint: [10.7942, 106.7217],
  },
  {
    id: 4,
    customerName: "Phạm Minh D",
    customerPhone: "0977 111 333",
    route: "Thủ Đức → Q1",
    pickupTime: "07:45 16/01/2026",
    status: "COMPLETED",
    price: 320000,
    startPoint: [10.849, 106.7719],
    endPoint: [10.7769, 106.7009],
  },
];

// ====== MOCK API ======
export const driverApi = {
  // Lấy danh sách chuyến của tài xế
  getMyTrips: async () => {
    await sleep(600); // giả delay network
    return MOCK_TRIPS;
  },

  // Cập nhật trạng thái chuyến
  updateTripStatus: async (tripId, nextStatus) => {
    await sleep(500);

    const idx = MOCK_TRIPS.findIndex((t) => t.id === tripId);
    if (idx === -1) {
      throw {
        response: { data: { message: "Không tìm thấy chuyến." } },
      };
    }

    MOCK_TRIPS[idx] = {
      ...MOCK_TRIPS[idx],
      status: nextStatus,
    };

    return {
      success: true,
      tripId,
      status: nextStatus,
    };
  },
};
